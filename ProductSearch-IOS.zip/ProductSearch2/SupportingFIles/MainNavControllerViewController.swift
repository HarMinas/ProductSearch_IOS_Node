//
//  MainNavControllerViewController.swift
//  ProductSearch2
//
//  Created by Harutyun Minasyan on 4/13/19.
//  Copyright © 2019 Harutyun Minasyan. All rights reserved.
//

import UIKit

class MainNavViewController: UINavigationController {
    var rootView = RootViewController()
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
